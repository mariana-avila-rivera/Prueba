import { Component } from '@angular/core';

@Component({
  selector: 'app-calculos',
  standalone: true,
  imports: [],
  templateUrl: './calculos.component.html',
  styleUrl: './calculos.component.css'
})
export class CalculosComponent {

}
